package assign09;

import java.util.ArrayList;
import java.util.Random;

public class StudentTimer {

	public static void main(String[] args) {

		int problemSize = 10000;

		int timesToLoop = 100;

		int incr = 1000;


		ArrayList<String> masterKeys = new ArrayList<>();
		ArrayList<Integer> masterVals = new ArrayList<>();

		String x = "";

		String y = "";

		int n = 0;
		Random r = new Random();
		r.setSeed(314);

		ArrayList<Integer> colls = new ArrayList<>();
		char[] c = new char[26];

		for (int i = 0; i < 26; i++) {
			c[i] = (char) (97 + i);
		}

		for (int i = 0; i < 200000; i++) {
			x = "";
			for (int j = 0; j < r.nextInt(7) + 2; j++) {
				x += c[r.nextInt(26)];
			}
			masterKeys.add(x);
			masterVals.add(r.nextInt(1000000));
		}
		
	
		

		for (problemSize = 1000; problemSize <= 20000; problemSize += incr) {

			HashTable<StudentGoodHash, Integer> ht = new HashTable<>();
			StudentGoodHash placeHold = new StudentGoodHash(11223344, "Hold", "Hold");
			
			for(int i = 0; i < problemSize; i++) {
				StudentGoodHash s = new StudentGoodHash(masterVals.get(i),masterKeys.get(i),masterKeys.get(i));
				ht.put(s, i);
			}
			


		}
		for (Integer i : colls) {
			System.out.println(i);
		}
	}

	
	
	
	
	
	
	public static ArrayList<Integer> generateAscending(int size) {
		ArrayList<Integer> result = new ArrayList<>();
		for (int i = 0; i < size; i++) {
			result.add(i);
		}
		return result;
	}

}